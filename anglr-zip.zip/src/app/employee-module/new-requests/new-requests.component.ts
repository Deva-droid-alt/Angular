import { Component } from '@angular/core';

@Component({
  selector: 'app-new-requests',
  templateUrl: './new-requests.component.html',
  styleUrl: './new-requests.component.css'
})
export class NewRequestsComponent {

}
