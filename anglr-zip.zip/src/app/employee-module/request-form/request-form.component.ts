import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { EmployeeService } from '../../services/employee.service';

@Component({
  selector: 'app-request-form',
  templateUrl:'./request-form.component.html',
  styleUrls: ['./request-form.component.css']
})
export class RequestFormComponent implements OnInit {
  managerName: string = ''; 

  formData: any = {
    firstName: '',
    lastName: '',
    
    modeOfTravel:'',
    fromLocation: '',
    toLocation: '',
    startDate: '',
    endDate: '',    
    lodgingRequired: false,
    lodgingInfo: '',
  };

  constructor(private http: HttpClient, private authService:EmployeeService) {}

  ngOnInit() {
    this.fetchManagerName();
  }

  fetchManagerName() {
    this.authService.getManagerName().subscribe({
      next: (response: any) => {
        this.managerName = response.manager_name;
        console.log('Manager Name:', this.managerName);
      },
      error: (error) => console.error('Error fetching manager:', error)
    });
  }
  


  submitForm() {
    const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
  
    if (!token) {
      console.error("No authentication token found. Please log in.");
      return;
    }
  
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Token ${token}`
    });
  
    const requestData = {
      from_location: this.formData.fromLocation,   // Corrected field names
      to_location: this.formData.toLocation,
      from_date: this.formData.startDate,
      to_date: this.formData.endDate,
      travel_mode: this.formData.modeOfTravel,
      purpose: this.formData.purpose // Make sure this exists in your form data
    };
  
    console.log("Submitting request:", requestData);  // Debugging
  
    this.http.post('http://127.0.0.1:8000/api/employee/travel_requests_new', requestData, { headers })
      .subscribe({
        next: response => console.log('Request submitted successfully!', response),
        error: error => console.error('Error submitting request:', error.error)
      });
  }
  

}
  

  
