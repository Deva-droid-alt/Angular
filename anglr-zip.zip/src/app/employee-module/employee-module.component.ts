import { Component } from '@angular/core';


@Component({
  selector: 'app-employee-module',
  templateUrl: './employee-module.component.html',
  styleUrl: './employee-module.component.css'
})
export class EmployeeModuleComponent {

}
