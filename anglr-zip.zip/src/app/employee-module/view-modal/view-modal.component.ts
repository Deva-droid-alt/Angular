import { Component } from '@angular/core';

// Define interface
interface TravelRequest {
  firstName: string;
  lastName: string;
  fromLocation: string;
  toLocation: string;
  fromDate: string;
  toDate: string;
  travel_mode: string;
  manager: string;
  accommodation_name: string;
  purpose: string;
  additional_note: string;
}

@Component({
  selector: 'app-view-modal',
  template: `
  <!-- Paste your HTML template here -->
  <!-- (The full HTML template you provided should be placed here) -->
  `,
  // styleUrls: ['./styles.css']
})
export class ViewModalComponent {
  isEditing: boolean = false;
  selectedRequest: TravelRequest = {
    firstName: '',
    lastName: '',
    fromLocation: '',
    toLocation: '',
    fromDate: '',
    toDate: '',
    travel_mode: '',
    manager: '',
    accommodation_name: '',
    purpose: '',
    additional_note: ''
  };

  // Edit toggle method
  toggleEdit(): void {
    this.isEditing = !this.isEditing;
  }

  // Save changes method
  saveChanges(): void {
    // Add your save logic here
    console.log('Saving travel request:', this.selectedRequest);
    
    // Typically you would call a service here
    // Example:
    // this.travelService.updateRequest(this.selectedRequest)
    //   .subscribe(() => handle success, error => handle error);
    
    this.isEditing = false;
  }

  // Optional: Input to receive data from parent component
  // @Input() initialData: TravelRequest;
  
  // Optional: Initialize with input data
  // ngOnInit() {
  //   if (this.initialData) {
  //     this.selectedRequest = {...this.initialData};
  //   }
  // }
}