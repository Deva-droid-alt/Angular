import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../../services/employee.service'; // Adjust the path to your service
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-empviewpage',
  templateUrl: './empviewpage.component.html',
  styleUrls: ['./empviewpage.component.css']
})
export class EmpviewpageComponent implements OnInit {
  travelRequests: any[] = [];  // Using 'any' since we don't have a model
  managerName: string = '';
  fromDate: string = '';
  toDate: string = '';
  sortOrder: string = 'asc';
  statusFilter: string = 'all';
  
  constructor(private employeeService: EmployeeService) {}

  // ngOnInit(): void {
  //   this.loadRequests();
  // }

  loadRequests(): void {
    this.employeeService.getTravelRequests().subscribe((data: any[]) => {
      this.travelRequests = data;
      this.managerName = data[0]?.manager ?? ''; // Assuming that first request will have the manager name
    });
  }

  filterRequests(): void {
    let filteredRequests = this.travelRequests;

    if (this.statusFilter !== 'all') {
      filteredRequests = filteredRequests.filter(request => request.status === this.statusFilter);
    }

    if (this.fromDate) {
      filteredRequests = filteredRequests.filter(request => new Date(request.from_date) >= new Date(this.fromDate));
    }

    if (this.toDate) {
      filteredRequests = filteredRequests.filter(request => new Date(request.to_date) <= new Date(this.toDate));
    }

    filteredRequests = this.sortRequests(filteredRequests);
    this.travelRequests = filteredRequests;
  }

  sortRequests(requests: any[]): any[] {
    return requests.sort((a, b) => {
      const dateA = new Date(a.date_submitted);
      const dateB = new Date(b.date_submitted);
      return this.sortOrder === 'asc' ? dateA.getTime() - dateB.getTime() : dateB.getTime() - dateA.getTime();
    });
  }

  viewRequest(request: any): void {
    // Logic to open modal and pass the selected request
    console.log('Viewing Request:', request);
    // You can open a modal here to view the request details.
  }

  editRequest(request: any): void {
    // Logic to handle editing request
    console.log('Editing Request:', request);
    // You can open a modal here to edit the request details.
  }

  deleteRequest(requestId: number): void {
    this.employeeService.deleteRequest(requestId).subscribe(() => {
      // Reload the requests after deletion
      this.loadRequests();
    });
  }

  onFilterChange(): void {
    this.filterRequests();
  }

  onSortChange(): void {
    this.filterRequests();
  }

  ngOnInit() {
    this.fetchManagerName();
  }

  fetchManagerName() {
    this.employeeService.getManagerName().subscribe({
      next: (response: any) => {
        this.managerName = response.manager_name;
        console.log('Manager Name:', this.managerName);
      },
      error: (error) => console.error('Error fetching manager:', error)
    });
  }

  

  
}


