import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient,HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://127.0.0.1:8000/api/employee/travel_requests_new/'; // Ensure the correct API endpoint

  constructor(private http: HttpClient) {}

  /** Login method */
  login(username: string, password: string): Observable<any> {
    return this.http.post<{ token: string }>('http://127.0.0.1:8000/api/login/', { username, password }).pipe(
      tap(response => {
        localStorage.setItem('authToken', response.token); // Store token
        console.log('Login successful, token stored:', response.token);
        console.log('Username:', username, 'Password:', password);
      }),
      map(() => true), // Return true on successful login
      catchError(error => {
        console.error('Login failed:', error);
        return throwError(() => new Error('Invalid username or password'));
      })
    );
  }
  

  /** Logout method */
  logout() {
    localStorage.removeItem('authToken');
    console.log('User logged out');
  }

  /** Get token from localStorage */
  private getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  /** Create travel request */
  createTravelRequest(requestData: any): Observable<any> {
    const token = this.getToken();
    
    if (!token) {
      console.error('User not authenticated');
      return throwError(() => new Error('User not authenticated'));
    }

    const headers = new HttpHeaders().set('Authorization', `Token ${token}`);

    return this.http.post(this.baseUrl, requestData, { headers }).pipe(
      tap(response => console.log('Travel request submitted:', response)),
      catchError(error => {
        console.error('Error submitting request:', error);
        return throwError(() => new Error('Failed to submit request'));
      })
    );
  }

  /** Get logged-in employee's manager */
  getManagerName(): Observable<any> {
    const token = this.getToken();

    if (!token) {
      console.error('User not authenticated');
      return throwError(() => new Error('User not authenticated'));
    }

    const headers = new HttpHeaders().set('Authorization', `Token ${token}`);

    return this.http.get('http://127.0.0.1:8000/api/employee/manager/', { headers }).pipe(
      tap(response => console.log('Manager fetched:', response)),
      catchError(error => {
        console.error('Error fetching manager:', error);
        return throwError(() => new Error('Failed to fetch manager'));
      })
    );
  }

  // Fetch travel requests with filters
  getTravelRequests(status?: string, fromDate?: string, sortBy?: string, order?: string): Observable<any> {
    let params = new HttpParams();
    
    if (status) params = params.set('status', status);
    if (fromDate) params = params.set('from_date', fromDate);
    if (sortBy) params = params.set('sort', sortBy);
    if (order) params = params.set('order', order);

    return this.http.get(`${this.baseUrl}filter/`, { params }).pipe(
      tap(response => console.log('Travel requests fetched:', response)),
      catchError(error => {
        console.error('Error fetching travel requests:', error);
        return throwError(() => new Error('Failed to fetch travel requests'));
      })
    );
  }

  /** Delete a travel request */
  deleteTravelRequest(requestId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}edit/${requestId}/`).pipe(
      tap(() => console.log(`Travel request ${requestId} deleted`)),
      catchError(error => {
        console.error(`Error deleting request ${requestId}:`, error);
        return throwError(() => new Error('Failed to delete travel request'));
      })
    );
  }

  /** Update a travel request */
  updateTravelRequest(requestId: number, data: any): Observable<any> {
    return this.http.patch(`${this.baseUrl}edit/${requestId}/`, data).pipe(
      tap(response => console.log(`Travel request ${requestId} updated:`, response)),
      catchError(error => {
        console.error(`Error updating request ${requestId}:`, error);
        return throwError(() => new Error('Failed to update travel request'));
      })
    );
  }

  deleteRequest(requestId: number): Observable<any> {
    return this.http.delete<any>(`${''}/travel-requests/${requestId}`);
  }
}



