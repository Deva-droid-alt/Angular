import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginSelectionComponent } from './login-selection/login-selection.component';


const routes: Routes = [
  { path: '', redirectTo: 'user-selection', pathMatch: 'full' }, // Redirect root to Login Selection
  { path: 'user-selection', component: LoginSelectionComponent }, // First page (Login Selection)
  { 
    path: 'employee',  
    loadChildren: () => import('./employee-module/employee-module.module').then(m => m.EmployeeModuleModule) 
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
