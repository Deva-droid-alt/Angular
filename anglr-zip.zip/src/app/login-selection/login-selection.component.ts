import { Component } from '@angular/core';

@Component({
  selector: 'app-login-selection',
  templateUrl: './login-selection.component.html',
  styleUrl: './login-selection.component.css'
})
export class LoginSelectionComponent {

}
